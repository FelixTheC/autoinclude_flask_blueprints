#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@created: 18.05.20
@author: felix
"""
__version__ = "0.1"
